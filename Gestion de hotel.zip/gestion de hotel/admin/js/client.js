function generateClientID() {
  return "CL-" + Date.now();
}

function afficherClients() {
  const tbody = document.getElementById("clientsTableBody");
  if (!tbody) return;

  let clients = JSON.parse(localStorage.getItem("clients")) || [];
  tbody.innerHTML = "";

  clients.forEach((client, index) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${client.id}</td>
      <td>${client.nom}</td>
      <td>${client.prenom}</td>
      <td>${client.email}</td>
      <td>${client.cin}</td>
      <td>${client.telephone}</td>
      <td>${client.fumeur}</td>
      <td>
        <button onclick="supprimerClient(${index})">🗑️</button>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

function supprimerClient(index) {
  let clients = JSON.parse(localStorage.getItem("clients")) || [];

  if (confirm("Es-tu sûr de vouloir supprimer ce client ? ❌")) {
    clients.splice(index, 1);
    localStorage.setItem("clients", JSON.stringify(clients));
    afficherClients();
  }
}

function annulerForm() {
  document.getElementById("clientForm").reset();
  document.getElementById("fumeurNon").checked = true;
}

document.addEventListener("DOMContentLoaded", () => {

  const toggleBtn = document.getElementById("toggleDarkMode");

  if (toggleBtn) {
    if (localStorage.getItem("darkMode") === "enabled") {
      document.body.classList.add("dark-mode");
      toggleBtn.innerHTML = "☀️ Light Mode";
    }

    toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
      const enabled = document.body.classList.contains("dark-mode");
      localStorage.setItem("darkMode", enabled ? "enabled" : "disabled");
      toggleBtn.innerHTML = enabled ? "☀️ Light Mode" : "🌙 Dark Mode";
    });
  }

  const form = document.getElementById("clientForm");
  if (!form) return;

  afficherClients();

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const nom = document.getElementById("clientNom").value.trim();
    const prenom = document.getElementById("clientPrenom").value.trim();
    const civilite = document.getElementById("clientCivilite").value;
    const dateNaissance = document.getElementById("clientDateNaissance").value;
    const nationalite = document.getElementById("clientNationalite").value;
    const pieceIdentite = document.getElementById("clientPieceIdentite").value;
    const email = document.getElementById("clientEmail").value.trim();
    const cin = document.getElementById("clientCIN").value.trim();
    const telephone = document.getElementById("clientTelephone").value.trim();
    const adresse = document.getElementById("clientAdresse").value.trim();
    const ville = document.getElementById("clientVille").value.trim();
    const fumeur = document.querySelector('input[name="fumeur"]:checked');

    if (!nom || !prenom || !civilite || !email || !telephone) {
      alert("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    const client = {
      id: generateClientID(),
      nom,
      prenom,
      civilite,
      dateNaissance,
      nationalite,
      pieceIdentite,
      email,
      cin,
      telephone,
      adresse,
      ville,
      fumeur: fumeur ? fumeur.value : "non"
    };

    let clients = JSON.parse(localStorage.getItem("clients")) || [];
    clients.push(client);
    localStorage.setItem("clients", JSON.stringify(clients));

    form.reset();
    document.getElementById("fumeurNon").checked = true;
    afficherClients();
  });
});
