document.addEventListener("DOMContentLoaded", () => {

  const session = JSON.parse(localStorage.getItem("sessionUser"));
  if (!session || session.role !== "admin") {
    window.location.href = "../login/index.html";
    return;
  }

  const clients = JSON.parse(localStorage.getItem("clients")) || [];
  const totalClients = document.getElementById("totalClients");
  if (totalClients) {
    totalClients.textContent = clients.length;
  }

  const chambres = JSON.parse(localStorage.getItem("chambres")) || [];
  const totalChambres = document.getElementById("totalChambres");
  if (totalChambres) {
    totalChambres.textContent = chambres.length;
  }

  const reservations = JSON.parse(localStorage.getItem("reservations")) || [];
  const totalReservations = document.getElementById("totalReservations");
  if (totalReservations) {
    totalReservations.textContent = reservations.length;
  }

});

const clients = JSON.parse(localStorage.getItem("clients")) || [];
const chambres = JSON.parse(localStorage.getItem("chambres")) || [];
const reservations = JSON.parse(localStorage.getItem("reservations")) || [];

const clientsCtx = document.getElementById("clientsChart");
if (clientsCtx) {
  new Chart(clientsCtx, {
    type: "pie",
    data: {
      labels: ["Clients"],
      datasets: [{
        label: "Nombres de clients",
        data: [clients.length]
      }]
    },
    options: {
      scales: { y: { beginAtZero: true } }
    }
  });
}

const chambresCtx = document.getElementById("chambresChart");
if (chambresCtx) {
  const disponibles = chambres.filter(c => c.disponible).length;
  const indisponibles = chambres.filter(c => !c.disponible).length;

  new Chart(chambresCtx, {
    type: "bar",
    data: {
      labels: ["Disponibles"],
      datasets: [{
        label:"Nombres des chambres",
        data: [disponibles, indisponibles]
      }]
    }
  });
}

const reservationsCtx = document.getElementById("reservationsChart");
if (reservationsCtx) {
  new Chart(reservationsCtx, {
    type: "bar",
    data: {
      labels: ["Réservations"],
      datasets: [{
        label: "Nombre de réservations",
        data: [reservations.length]
      }]
    },
    options: {
      scales: { y: { beginAtZero: true } }
    }
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("toggleDarkMode");
  if (!btn) return;

  if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
    btn.innerHTML = "☀️ Light Mode";
  }

  btn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "enabled" : "disabled");
    btn.innerHTML = enabled ? "☀️ Light Mode" : "🌙 Dark Mode";
  });
});
