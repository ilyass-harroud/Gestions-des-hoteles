function generateChambreID() {
  return "CH-" + Date.now();
}

function afficherChambres() {
  const tbody = document.getElementById("chambresTableBody");
  if (!tbody) return;

  const chambres = JSON.parse(localStorage.getItem("chambres")) || [];
  tbody.innerHTML = "";

  chambres.forEach((chambre, index) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${chambre.numero}</td>
      <td>${chambre.type}</td>
      <td>${chambre.prix} DH</td>
      <td>
        <button class="btn btn-danger btn-sm" onclick="supprimerChambre(${index})">
          🗑️
        </button>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

function supprimerChambre(index) {
  let chambres = JSON.parse(localStorage.getItem("chambres")) || [];

  if (confirm("Supprimer cette chambre ? ❌")) {
    chambres.splice(index, 1);
    localStorage.setItem("chambres", JSON.stringify(chambres));
    afficherChambres();
  }
}

document.addEventListener("DOMContentLoaded", function () {

  const form = document.getElementById("chambreForm");

  afficherChambres();

  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const numero = document.getElementById("numeroChambre").value.trim();
    const type = document.getElementById("typeChambre").value;
    const prix = document.getElementById("prixChambre").value.trim();

    if (numero === "" || prix === "") {
      alert("Veuillez remplir tous les champs ❗");
      return;
    }

    let chambres = JSON.parse(localStorage.getItem("chambres")) || [];

    const existe = chambres.some(c => c.numero === numero);
    if (existe) {
      alert("Cette chambre existe déjà ❌");
      return;
    }

    const chambre = {
      id: generateChambreID(),
      numero,
      type,
      prix,
      disponible: true
    };

    chambres.push(chambre);
    localStorage.setItem("chambres", JSON.stringify(chambres));

    form.reset();
    afficherChambres();
  });
});


document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("toggleDarkMode");
  if (!btn) return;

  if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
    btn.innerHTML = "☀️ Light Mode";
  }

  btn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "enabled" : "disabled");
    btn.innerHTML = enabled ? "☀️ Light Mode" : "🌙 Dark Mode";
  });
});
