document.addEventListener("DOMContentLoaded", () => {

  const T = {
    fr: {
      sidebar: {
        dashboard: "Tableau de bord",
        client: "Clients",
        chambre: "Chambres",
        logout: "Déconnexion"
      },
      dashboard: {
        title: "Tableau de bord",
        search: "Rechercher...",
        clients: "Clients",
        chambres: "Chambres",
        reservations: "Réservations",
        dispo: "Chambres disponibles",
        indispo: "Chambres indisponibles"
      },
      client: {
        title: "Ajouter un Nouveau Client",
        back: "Retour à la liste",
        info: "Informations du client",
        personal: "Informations Personnelles",
        contact: "Coordonnées",
        nom: "Nom",
        prenom: "Prénom",
        email: "Email",
        cin: "CIN",
        phone: "Téléphone",
        fumeur: "Fumeur ?",
        yes: "Oui",
        no: "Non",
        submit: "Ajouter le Client",
        list: "📋 Liste des Clients"
      },
      chambre: {
        breadcrumb: "Chambres",
        title: "Gestion des chambres",
        numero: "Numéro chambre",
        type: "Type",
        prix: "Prix / Nuit",
        add: "Ajouter chambre",
        simple: "Simple",
        double: "Double",
        suite: "Suite",
        thNumero: "Numéro",
        thType: "Type",
        thPrix: "Prix",
        search: "Rechercher..."
      }
    },

    en: {
      sidebar: {
        dashboard: "Dashboard",
        client: "Clients",
        chambre: "Rooms",
        logout: "Logout"
      },
      dashboard: {
        title: "Dashboard",
        search: "Search...",
        clients: "Clients",
        chambres: "Rooms",
        reservations: "Reservations",
        dispo: "Available rooms",
        indispo: "Unavailable rooms"
      },
      client: {
        title: "Add New Client",
        back: "Back to list",
        info: "Client Information",
        personal: "Personal Information",
        contact: "Contact Details",
        nom: "Last Name",
        prenom: "First Name",
        email: "Email",
        cin: "ID Number",
        phone: "Phone",
        fumeur: "Smoker?",
        yes: "Yes",
        no: "No",
        submit: "Add Client",
        list: "📋 Clients List"
      },
      chambre: {
        breadcrumb: "Rooms",
        title: "Room Management",
        numero: "Room Number",
        type: "Type",
        prix: "Price / Night",
        add: "Add Room",
        simple: "Single",
        double: "Double",
        suite: "Suite",
        thNumero: "Number",
        thType: "Type",
        thPrix: "Price",
        search: "Search..."
      }
    },

    ar: {
      sidebar: {
        dashboard: "لوحة التحكم",
        client: "الزبناء",
        chambre: "الغرف",
        logout: "تسجيل الخروج"
      },
      dashboard: {
        title: "لوحة التحكم",
        search: "بحث...",
        clients: "الزبناء",
        chambres: "الغرف",
        reservations: "الحجوزات",
        dispo: "الغرف المتوفرة",
        indispo: "الغرف غير المتوفرة"
      },
      client: {
        title: "إضافة زبون جديد",
        back: "الرجوع إلى اللائحة",
        info: "معلومات الزبون",
        personal: "المعلومات الشخصية",
        contact: "معلومات الاتصال",
        nom: "النسب",
        prenom: "الاسم الشخصي",
        email: "البريد الإلكتروني",
        cin: "رقم البطاقة",
        phone: "الهاتف",
        fumeur: "مدخن؟",
        yes: "نعم",
        no: "لا",
        submit: "إضافة الزبون",
        list: "📋 لائحة الزبناء"
      },
      chambre: {
        breadcrumb: "الغرف",
        title: "إدارة الغرف",
        numero: "رقم الغرفة",
        type: "النوع",
        prix: "السعر / الليلة",
        add: "إضافة غرفة",
        simple: "مفردة",
        double: "مزدوجة",
        suite: "جناح",
        thNumero: "الرقم",
        thType: "النوع",
        thPrix: "السعر",
        search: "بحث..."
      }
    }
  };

  let lang = localStorage.getItem("lang") || "fr";
  const t = T[lang];

  const qs = s => document.querySelector(s);
  const qsa = s => document.querySelectorAll(s);
  const setText = (s, v) => qs(s) && (qs(s).textContent = v);

  setText('[data-i18n="dashboard"]', t.sidebar.dashboard);
  setText('[data-i18n="client"]', t.sidebar.client);
  setText('[data-i18n="chambre"]', t.sidebar.chambre);
  setText('[data-i18n="common.logout"]', t.sidebar.logout);

  if (qs("#dashboardSection")) {
    setText("#dashboardSection h1", t.dashboard.title);
    qs("#globalSearch") && (qs("#globalSearch").placeholder = t.dashboard.search);

    qsa(".kpi-card span").forEach(span => {
      if (span.textContent.includes("Clients")) span.textContent = t.dashboard.clients;
      if (span.textContent.includes("Chambres")) span.textContent = t.dashboard.chambres;
      if (span.textContent.includes("Réservations")) span.textContent = t.dashboard.reservations;
      if (span.textContent.includes("disponibles")) span.textContent = t.dashboard.dispo;
      if (span.textContent.includes("indisponibles")) span.textContent = t.dashboard.indispo;
    });
  }

  if (qs("#clientForm")) {
    setText("h1", t.client.title);
    setText(".section-header span", t.client.back);
    setText(".form-header-client h2", t.client.info);

    qsa("label[for='clientNom']").forEach(l => l.firstChild.textContent = t.client.nom + " ");
    qsa("label[for='clientPrenom']").forEach(l => l.firstChild.textContent = t.client.prenom + " ");
    qsa("label[for='clientEmail']").forEach(l => l.firstChild.textContent = t.client.email + " ");
    qsa("label[for='clientCIN']").forEach(l => l.firstChild.textContent = t.client.cin + " ");
    qsa("label[for='clientTelephone']").forEach(l => l.firstChild.textContent = t.client.phone + " ");

    const smoker = qs(".radio-group-client")?.closest(".client-form-group")?.querySelector("label");
    smoker && (smoker.textContent = t.client.fumeur);

    setText('label[for="fumeurOui"]', t.client.yes);
    setText('label[for="fumeurNon"]', t.client.no);

    setText("#btnSubmitClient", t.client.submit);
    setText(".clients-list-container h3", t.client.list);
  }

  if (qs("#chambreForm")) {
    setText(".breadcrumb span", t.chambre.breadcrumb);
    setText(".content h2", t.chambre.title);

    qsa("label").forEach(l => {
      if (l.textContent.includes("Numéro")) l.textContent = t.chambre.numero;
      if (l.textContent === "Type") l.textContent = t.chambre.type;
      if (l.textContent.includes("Prix")) l.textContent = t.chambre.prix;
    });

    setText("#chambreForm button", t.chambre.add);

    const sel = qs("#typeChambre");
    if (sel) {
      sel.options[0].text = t.chambre.simple;
      sel.options[1].text = t.chambre.double;
      sel.options[2].text = t.chambre.suite;
    }

    const ths = qsa("table thead th");
    ths[0] && (ths[0].textContent = t.chambre.thNumero);
    ths[1] && (ths[1].textContent = t.chambre.thType);
    ths[2] && (ths[2].textContent = t.chambre.thPrix);

    qs(".search-box input") && (qs(".search-box input").placeholder = t.chambre.search);
  }

  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

  const select = qs("#languageSelect");
  if (select) {
    select.value = lang;
    select.addEventListener("change", e => {
      localStorage.setItem("lang", e.target.value);
      location.reload();
    });
  }
});
