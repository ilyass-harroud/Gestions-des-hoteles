document.addEventListener("DOMContentLoaded", () => {
  const selectLang = document.getElementById("language");

  const translations = {
    fr: {
      title: "Hôtel Manager Pro - Connexion",
      subtitle: "Système de gestion hôtelière",
      email: "Email",
      password: "Mot de passe ou CIN",
      login: "Se connecter",
      testAccounts: "Comptes de test :"
    },
    en: {
      title: "Hotel Manager Pro - Login",
      subtitle: "Hotel management system",
      email: "Email",
      password: "Password or ID",
      login: "Sign in",
      testAccounts: "Test accounts:"
    },
    ar: {
      title: "مدير الفندق برو - تسجيل الدخول",
      subtitle: "نظام إدارة الفنادق",
      email: "البريد الإلكتروني",
      password: "كلمة المرور أو رقم البطاقة",
      login: "تسجيل الدخول",
      testAccounts: "حسابات تجريبية:"
    }
  };

  const savedLang = localStorage.getItem("lang") || "fr";
  selectLang.value = savedLang;
  applyLanguage(savedLang);

  selectLang.addEventListener("change", () => {
    const lang = selectLang.value;
    localStorage.setItem("lang", lang);
    applyLanguage(lang);
  });

  function applyLanguage(lang) {
    const t = translations[lang];

    document.title = t.title;
    document.querySelector(".subtitle").textContent = t.subtitle;
    document.querySelector('label[for="email"]').innerHTML =
      `<i class="fas fa-envelope"></i> ${t.email}`;
    document.querySelector('label[for="password"]').innerHTML =
      `<i class="fas fa-lock"></i> ${t.password}`;
    document.querySelector(".btn-login").innerHTML =
      `<i class="fas fa-sign-in-alt"></i> ${t.login}`;
    document.querySelector(".login-info strong").textContent =
      t.testAccounts;

    if (lang === "ar") {
      document.documentElement.setAttribute("dir", "rtl");
      document.documentElement.setAttribute("lang", "ar");
    } else {
      document.documentElement.setAttribute("dir", "ltr");
      document.documentElement.setAttribute("lang", lang);
    }
  }
});
