const users = JSON.parse(localStorage.getItem("clients")) || [];

document.getElementById("loginForm")?.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    let user = null;

    if (email === "admin@app.com" && password === "admin123") {
        user = {
            email,
            role: "admin"
        };
    } 
    else {
        user = users.find(
            u => u.email === email && u.cin === password
        );

        if (user) {
            user.role = "user";
        }
    }

    if (!user) {
        alert("Login incorrect ❌");
        return;
    }

    localStorage.setItem("sessionUser", JSON.stringify(user));

    if (user.role === "admin") {
        window.location.href = "../admin/dashboard.html";
    } else {
        window.location.href = "../user/chambre.html";
    }
});
function logout() {
  localStorage.removeItem("sessionUser");
  window.location.href = "../login/index.html";
}
