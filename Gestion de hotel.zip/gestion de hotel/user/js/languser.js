const translations = {
  fr: {
    chambre: "Chambres",
    reservation: "Réservations",
    "common.search": "Rechercher...",
    "common.logout": "Déconnexion",

    "chambre.title": "Chambres",
    "chambre.available": "Nos chambres disponibles",

    "reservation.title": "Mes Réservations",
    "reservation.room": "Chambre",
    "reservation.type": "Type",
    "reservation.price": "Prix",
    "reservation.date": "Date",
    "reservation.status": "Statut"
  },

  en: {
    chambre: "Rooms",
    reservation: "Reservations",
    "common.search": "Search...",
    "common.logout": "Logout",

    "chambre.title": "Rooms",
    "chambre.available": "Available Rooms",

    "reservation.title": "My Reservations",
    "reservation.room": "Room",
    "reservation.type": "Type",
    "reservation.price": "Price",
    "reservation.date": "Date",
    "reservation.status": "Status"
  },

  ar: {
    chambre: "الغرف",
    reservation: "الحجوزات",
    "common.search": "بحث...",
    "common.logout": "تسجيل الخروج",

    "chambre.title": "الغرف",
    "chambre.available": "الغرف المتوفرة",

    "reservation.title": "حجوزاتي",
    "reservation.room": "الغرفة",
    "reservation.type": "النوع",
    "reservation.price": "السعر",
    "reservation.date": "التاريخ",
    "reservation.status": "الحالة"
  }
};

function applyLanguage(lang) {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (translations[lang][key]) {
      el.placeholder = translations[lang][key];
    }
  });

  localStorage.setItem("language", lang);
}

document.addEventListener("DOMContentLoaded", () => {
  const select = document.getElementById("languageSelect");
  const savedLang = localStorage.getItem("language") || "fr";

  applyLanguage(savedLang);

  if (select) {
    select.value = savedLang;
    select.addEventListener("change", e => {
      applyLanguage(e.target.value);
    });
  }
});
