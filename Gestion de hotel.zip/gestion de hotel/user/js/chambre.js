document.addEventListener("DOMContentLoaded", function () {

  const container = document.getElementById("chambresUserList");
  if (!container) return;

  const session = JSON.parse(localStorage.getItem("sessionUser"));
  if (!session || session.role !== "user") {
    window.location.href = "../login/index.html";
    return;
  }

  const chambres = JSON.parse(localStorage.getItem("chambres")) || [];

  if (chambres.length === 0) {
    container.innerHTML = "<p>Aucune chambre disponible.</p>";
    return;
  }

  chambres.forEach(chambre => {
    const col = document.createElement("div");
    col.className = "col-md-4 mb-4";

    col.innerHTML = `
      <div class="card h-100">
        <div class="card-body">
          <h5 class="card-title">Chambre ${chambre.numero}</h5>
          <p>
            <strong>Type :</strong> ${chambre.type}<br>
            <strong>Prix :</strong> ${chambre.prix} DH / nuit
          </p>
          <button class="btn btn-success w-100"
            onclick="reserverChambre('${chambre.id}')">
            Réserver
          </button>
        </div>
      </div>
    `;

    container.appendChild(col);
  });
});

function reserverChambre(chambreId) {

  const session = JSON.parse(localStorage.getItem("sessionUser"));
  if (!session) return;

  const chambres = JSON.parse(localStorage.getItem("chambres")) || [];
  const reservations = JSON.parse(localStorage.getItem("reservations")) || [];

  const chambre = chambres.find(c => c.id === chambreId);
  if (!chambre) return;

  const dejaReserve = reservations.some(
    r => r.clientEmail === session.email || r.chambre === chambre.numero
  
  );
  
  if (dejaReserve) {
    alert("Vous avez déjà réservé cette chambre ❌");
    return;
  }

  const reservation = {
    id: "RES-" + Date.now(),
    clientEmail: session.email,
    chambre: chambre.numero,
    type: chambre.type,
    prix: chambre.prix,
    status: "Confirmée",
    date: new Date().toLocaleDateString()
  };

  reservations.push(reservation);
  localStorage.setItem("reservations", JSON.stringify(reservations));
  

  alert("Réservation ajoutée avec succès ✅");

  window.location.href = "reservation.html";
}

document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleDarkMode");

  if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
  }

  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");

      if (document.body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
        toggleBtn.innerHTML = "☀️ Light Mode";
      } else {
        localStorage.setItem("darkMode", "disabled");
        toggleBtn.innerHTML = "🌙 Dark Mode";
      }
    });
  }
});
