document.addEventListener("DOMContentLoaded", function () {

  const session = JSON.parse(localStorage.getItem("sessionUser"));
  if (!session || session.role !== "user") {
    window.location.href = "../login/index.html";
    return;
  }

  const tbody = document.getElementById("reservationsTableBody");
  if (!tbody) return;

  const reservations = JSON.parse(localStorage.getItem("reservations")) || [];

  const mesReservations = reservations.filter(
    r => r.clientEmail === session.email
  );

  tbody.innerHTML = "";

  if (mesReservations.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center">
          Aucune réservation trouvée
        </td>
      </tr>
    `;
    return;
  }

  mesReservations.forEach(res => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>Chambre ${res.chambre}</td>
      <td>${res.type}</td>
      <td>${res.prix} DH</td>
      <td>${res.date}</td>
      <td>
        <span class="badge bg-success">
          ${res.status}
        </span>
      </td>
    `;

    tbody.appendChild(tr);
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleDarkMode");

  if (!toggleBtn) return;

  const isDark = localStorage.getItem("darkMode") === "enabled";

  if (isDark) {
    document.body.classList.add("dark-mode");
    toggleBtn.innerHTML = "☀️ Light Mode";
  }

  toggleBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "enabled" : "disabled");

    toggleBtn.innerHTML = enabled ? "☀️ Light Mode" : "🌙 Dark Mode";
  });
});
