function getData(key) {
  return JSON.parse(localStorage.getItem(key)) || [];
}

function loadDashboard() {
  const clients = getData("clients");
  document.getElementById("totalClients").innerText = clients.length;

  const reservations = getData("reservations");
  document.getElementById("reservations").innerText = reservations.length;

  let total = reservations.reduce((sum, r) => {
    return sum + (Number(r.prix) || 0);
  }, 0);
  document.getElementById("revenus").innerText = total + " DH";

  const chambres = getData("chambres");
  let occ = 0;
  if (chambres.length > 0) {
    let occupees = chambres.filter(c => c.statut === "Occupée").length;
    occ = Math.round((occupees / chambres.length) * 100);
  }
  document.getElementById("occupation").innerText = occ + "%";
}

window.onload = loadDashboard;


document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleDarkMode");

  if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
  }

  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");

      if (document.body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
        toggleBtn.innerHTML = "☀️ Light Mode";
      } else {
        localStorage.setItem("darkMode", "disabled");
        toggleBtn.innerHTML = "🌙 Dark Mode";
      }
    });
  }
});


